package com.darmi.constants;

public class Constants {
    //parametros world
    public static final int WORLD_WIDTH=72;
    public static final int WORLD_HEIGHT=128;
}
